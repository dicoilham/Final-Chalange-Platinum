#Import Flask
from flask import Flask, jsonify
from flask import request
from flasgger import Swagger, LazyString, LazyJSONEncoder
from flasgger import swag_from

import pickle5 as pickle
import sqlite3
import re
import pandas as pd
import numpy as np
import tensorflow
from keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from collections import defaultdict

# Initialize Flask API =================================================================
app = Flask(__name__)
app.json_encoder = LazyJSONEncoder
swagger_template = dict(
info = {
    'title': LazyString(lambda: 'API Sentiment Analysis Kelompok 3'),
    'version': LazyString(lambda: '1.0.0'),
    'description': LazyString(lambda: 'API Sentiment Analysis - Kelompok 3 (Pram, Dico, Hisyam)')
    },
    host = LazyString(lambda: request.host)
)
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json',
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}
# Initialize Swagger from swagger_template & swagger_config============================================
swagger = Swagger(app, template=swagger_template, 
                  config=swagger_config)

#connect db
# conn = sqlite3.connect('output.db', check_same_thread=False)
# #create table
# conn.execute('''CREATE TABLE IF NOT EXISTS text_lstm (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')
# conn.execute('''CREATE TABLE IF NOT EXISTS file_lstm (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')


#initialize LSTM feature
max_features = 100000
tokenizer = Tokenizer(num_words=max_features, split=' ', lower=True)

sentiment = ['negative','neutral','positive']

#cleansing function
def cleansing(sent):
    string = sent.lower()

    string = re.sub(r'[^a-zA-Z0-9]',' ',string)
    return string



#load pickle feature lstm
file = open("x_pad_sequences.pickle",'rb')
feature_file_from_lstm = pickle.load(file)
file.close()

model_file_from_lstm = load_model('model_lstm.h5')

# Input Text
@swag_from('docs/LSTM_text.yml', methods=['POST'])
@app.route('/lstm_text', methods=['POST'])
def lstm_text():

    original_text = request.form.get('text')
    text = [cleansing(original_text)]

    predicted = tokenizer.texts_to_sequences(text)
    guess = pad_sequences(predicted, maxlen=feature_file_from_lstm.shape[1])

    prediction = model_file_from_lstm.predict(guess)
    get_sentiment = sentiment[np.argmax(prediction[0])]

    # query = "insert into text_lstm (text, sentiment) values (?, ?)"
    # val = (text, str(get_sentiment))
    # conn.execute(query, val)
    # conn.commit()


    json_response = {
        'status_code' : 200,
        'description' : "Result of Sentiment Analysis using LSTM",
        'data' : {
            'text': original_text,
            'sentiment': get_sentiment
        },
    }
    response_data = jsonify(json_response)
    return response_data

#input File
@swag_from('docs/LSTM_file.yml', methods=['POST'])
@app.route('/lstm_file', methods=['POST'])
def lstm_file():

    original_file = request.file.getlist('file')

if __name__ == '__main__':
    app.run()