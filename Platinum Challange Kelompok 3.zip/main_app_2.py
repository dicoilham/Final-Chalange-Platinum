# Import Library
import pandas as pd
import numpy as np
import re
import sqlite3
import joblib
import nltk
import pickle5 as pickle
import tensorflow
import Sastrawi
from flasgger import Swagger, swag_from, LazyJSONEncoder, LazyString
from flask import Flask, jsonify, request, make_response
from sklearn import metrics
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Flatten
from tensorflow.keras.callbacks import EarlyStopping, TensorBoard
from tensorflow.keras import optimizers
from tensorflow.keras.layers import Dense, Embedding, LSTM, SpatialDropout1D, SimpleRNN, Activation
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers
from collections import defaultdict
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, classification_report
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from keras.models import load_model
from nltk.corpus import stopwords as stpw
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory


factory = StemmerFactory()
stemmer = factory.create_stemmer()

# from nltk import word_tokenize
# nltk.download('punkt')
# nltk.download('stopwords')

# Flask
# Initialize Flask API =================================================================
app = Flask(__name__)
# assign LazyJSONEncoder to app.json_encoder for Swagger to work
app.json_encoder = LazyJSONEncoder
# Create Swagger Config object & Swagger template
swagger_template = dict(
info = {
    'title': LazyString(lambda: 'API Sentiment Analysis Kelompok 3'),
    'version': LazyString(lambda: '1.0.0'),
    'description': LazyString(lambda: 'API Sentiment Analysis - Kelompok 3 (Pram, Dico, Hisyam)')
    },
    host = LazyString(lambda: request.host)
)
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json'
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}
# Initialize Swagger from swagger_template & swagger_config============================================
swagger = Swagger(app, template=swagger_template, 
                  config=swagger_config)



sentiment = ['negative', 'neutral', 'positive']

# Connect to db & read csv
conn = sqlite3.connect('output.db', check_same_thread=False)
df_alay = pd.read_csv('new_kamusalay.csv', names=[
                      'alay', 'cleaned'], encoding='latin-1')
data_mentah = pd.read_csv('train_preprocess.tsv.txt',
                          sep='\t', names=['text', 'label'])
data_mentah = data_mentah.drop_duplicates()

# Create table
# conn.execute('''CREATE TABLE IF NOT EXISTS text_nn (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')
# conn.execute('''CREATE TABLE IF NOT EXISTS file_nn (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')
# conn.execute('''CREATE TABLE IF NOT EXISTS text_tf (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')
# conn.execute('''CREATE TABLE IF NOT EXISTS file_tf (id INTEGER PRIMARY KEY AUTOINCREMENT, text varchar(255), sentiment varchar(255));''')

# # Membuat Stopwords
# list_stopwords = stpw.words('indonesian')
# list_stopwords_en = stpw.words('english')
# list_stopwords.extend(list_stopwords_en)
# list_stopwords.extend(['nya', 'ya', 'ga', 'yg', 'kali', 'yuk', 'jgn'])
# list_stopwords_baru = list_stopwords

# Fungsi buat cleaning=================================================================================


def lowercase(text):  # remove lowercase
    return text.lower()


def nonalphanumeric(text):  # remove nonaplhanumeric
    text = re.sub(r'[^0-9a-zA-Z]+', ' ', text, flags=re.MULTILINE)
    return text


def unnecessary_char(text):
    # Remove every special charachters
    text = re.sub(r'\W', ' ', str(text), flags=re.MULTILINE)
    # Remove every retweet symbol
    text = re.sub(r'rt', ' ', text, flags=re.MULTILINE)
    # Remove every username
    text = re.sub(r'user', ' ', text, flags=re.MULTILINE)
    text = re.sub(r'((www\.[^\s]+)|(https?://[^\s]+)|(http?://[^\s]+))',
                  ' ', text, flags=re.MULTILINE)  # Remove every URL
    # Subtitute multi spaces with single space
    text = re.sub(r'\s+', ' ', text, flags=re.MULTILINE)
    return text


# formating kamusalay
format_alay = dict(zip(df_alay['alay'], df_alay['cleaned']))


def cleaning_alay(text):  # Remove 'alay' words
    split_text_alay = text.split()
    text_alay = [format_alay.get(x, x) for x in split_text_alay]
    cleaned_alay = ' '.join(text_alay)
    return cleaned_alay


# def StopWords(text):  # Create Stopwords lists
#     text_tokens = word_tokenize(text)
#     tokens_without_stopwords = [
#         word for word in text_tokens if not word in list_stopwords_baru]
#     without_stopwords = ' '.join(tokens_without_stopwords)
#     return without_stopwords


def stemming(text):
    return stemmer.stem(text)

    # Function for text cleansing


def cleaning(text):
    text = lowercase(text)
    text = nonalphanumeric(text)
    text = unnecessary_char(text)
    text = cleaning_alay(text)
    # text = StopWords(text)
    text = stemming(text)
    return text

# Neural Network Model=================================================================================================
# Load file pickle and model NN
file = open("featurebow.pickle", 'rb')
feature_nn = pickle.load(file)
file.close()

file2 = open('ModelNN_bow.pickle', 'rb')
model_nn = pickle.load(file2)
file2.close()

# Input Text
@swag_from('docs/NN_text.yml', methods=['POST'])
@app.route('/NN_text', methods=['POST'])
def NN_text():
    # input text
    input_text = str(request.form.get('text'))
    # cleaning
    cleaned_text = cleaning(input_text)
    # feature extract + predict
    # prediction = model_nn.predict(feature_nn.transform(cleaned_text).toarray())
    feature = feature_nn.transform(cleaned_text)
    # feature extract + predict
    prediction = model_nn.predict(feature)[0]


    # get_sentiment = sentiment(np.argmax(prediction[0]))
    # query
    # query = "insert into nn_text (text, sentiment) values (?, ?)"
    # val = (cleaned_text, str(prediction))
    # conn.execute(query, val)
    # conn.commit()

    json_response = {
        # API response
        'status_code': 200,
        'description': "Sentiment Analysis Menggunakan Model Neural Network Success",
        'text':input_text,
        'sentiment': prediction
        }
    response_data = jsonify(json_response)
    return response_data

# Input File
@swag_from('docs/NN_file.yml', methods=['POST'])
@app.route('/NN_file', methods=['POST'])
# function for csv
def NN_csv():
    # input file
    file = request.file.getlist('file')[0]
    csv_file = pd.read_csv(file, names=['text'], header=None)
    texts = csv_file.text.to_list()
    text_sentiment = []
    for text_awal in texts :
        cleaned_text2 = cleaning(text_awal)  # cleaning
        text_sentiment.append(cleaned_text2)
        # feature extract + predict
        prediction = model_nn.predict(feature_nn.transform([cleaned_text2]).toarray())

        text_sentiment.append({
            'text':text_awal,
            'sentiment': prediction
      })
    # query
    # query2 = "insert into nn_file (text, sentiment) values (?, ?)"
    # val = (cleaned_text2, str(prediction2))
    # conn.execute(query2, val)
    # conn.commit()

    json_response = {
      'status_code': 200,
      'description': "Neural Network Result of Sentiment Analysis",
      'data': text_sentiment,
    }
    response_data = jsonify(json_response)
    return response_data


# TENSORFLOW LSTM MODEL======================================================================================================
# Load model LSTM
model = load_model('model_lstm.h5')
#tokenizer = joblib.load('tokenizer.pickle')
file = open("x_pad_sequences.pickle", 'rb')
X = pickle.load(file)
file.close()

# Input Text Analysis Tensorflow
@swag_from('docs/LSTM_text.yml', methods=['POST'])
@app.route('/LSTM_text', methods=['POST'])

def LSTM_TEXT():
    # input text
    input_text = request.form.get('text')
    # cleaning
    cleaned_text = cleaning(input_text)
    feature = pad_sequences(cleaned_text, maxlen=X.shape[1])  # feature extract
    # prediksi
    prediction = model.predict(feature)

    get_sentiment = sentiment(np.argmax(prediction[0]))

    # # query
    # query = "insert into text_lstm (text, sentiment) values (?, ?)"
    # val = (cleaned_text, str(prediction))
    # conn.execute(query, val)
    # conn.commit()

    json_response = {
        # API response
        'status_code': 200,
        'description': "Sentiment Analysis Menggunakan Model LSTM",
        'data': {
            'text': cleaned_text,
            'sentiment': get_sentiment
        },
    }
    response_data = jsonify(json_response)
    return response_data

# Input File Analysis Tensorflow
@swag_from('docs/LSTM_file.yml', methods=['POST'])
@app.route('/LSTM_file', methods=['POST'])
def LSTM_FILE():
    # input file
    file = request.file.getlist('file')[0]
    csv_file = pd.read_csv(file, names=['text'], header=None)
    texts = csv_file.text.to_list()

    text_sentiment = []

    for text_awal in texts :
        cleaned_text2 = cleaning(texts)  # cleaning
        text_sentiment.append(cleaned_text2 )
        feature2 = pad_sequences(cleaned_text2, maxlen=X.shape[1])  # feature extract
        prediction2 = model.predict(feature2)
        get_sentiment = sentiment(np.argmax(prediction2[0]))

        text_sentiment.append({
        'text':text_awal,
        'sentiment': get_sentiment
      }) 

    # # query
    # query2 = "insert into lstm_file (text, sentiment) values (?, ?)"
    # val = (cleaned_text2, str(prediction2))
    # conn.execute(query2, val)
    # conn.commit()

    json_response = {
      'status_code': 200,
      'description': "LSTM Result of Sentiment Analysis",
      'data': text_sentiment,
    }
    response_data = jsonify(json_response)
    return response_data

# # Error Handling
# @app.errorhandler(400)
# def handle_400_error(_error):
#     "Return a http 400 error"
#     return make_response(jsonify({'error': 'Misunderstood'}), 400)


# @app.errorhandler(401)
# def handle_401_error(_error):
#     "Return a http 401 error"
#     return make_response(jsonify({'error': 'Unauthorized'}), 401)


# @app.errorhandler(404)
# def handle_404_error(_error):
#     "Return a http 404 error"
#     return make_response(jsonify({'error': 'Not found'}), 404)


# @app.errorhandler(500)
# def handle_400_error(_error):
#     "Return a http 500 error"
#     return make_response(jsonify({'error': 'Server Error'}), 500)


if __name__ == '__main__':
    app.run(debug=True)

